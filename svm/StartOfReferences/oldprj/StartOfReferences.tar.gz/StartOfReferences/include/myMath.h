#ifndef __MY_MATH_H__
#define __MY_MATH_H__

double getVariance(int list[],int len);

#endif // __MY_MATH_H__
