#ifndef __DEBUG_INFO_H__
#define __DEBUG_INFO_H__

// for debug
int printfContext(int refOffset);

#endif // __DEBUG_INFO_H__
