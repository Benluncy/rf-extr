#ifndef __DIR_TRAVERSAL_H__
#define __DIR_TRAVERSAL_H__

int dirTraversal(const char *path, int recursive);


#endif //__DIR_TRAVERSAL_H__
